

    <footer class="bg-gray-800 text-white py-4 mt-auto">
        <div class="container mx-auto text-center">
            <p class="text-gray-400">&copy; 2019 UniVol. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
